<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database ='food_ordering_system';

$connection = mysqli_connect($host, $user, $password, $database);
